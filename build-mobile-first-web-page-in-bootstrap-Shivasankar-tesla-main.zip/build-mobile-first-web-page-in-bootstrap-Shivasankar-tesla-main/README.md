# Build_mobile-first-web-page-in-Bootstrap

# Build-mobile-first-web-page-in-Bootstrap

Refer to the attached document for the assignment.  In total you need to create five pages linked to each other through a common nav bar. You are not supposed to use any custom CSS in this assignment. The buttons provided in the layout sections need to be functional(they are not suppose to perform any action). 



![image](https://user-images.githubusercontent.com/69638895/111909846-e5c2d800-8a84-11eb-8e5c-6ef89e5acb7b.png)


![image](https://user-images.githubusercontent.com/69638895/111909867-fc692f00-8a84-11eb-96fe-929966a1ce6f.png)

![image](https://user-images.githubusercontent.com/69638895/111910032-ae086000-8a85-11eb-802f-da4285f5b944.png)

![image](https://user-images.githubusercontent.com/69638895/111910083-f293fb80-8a85-11eb-8e80-c1560d6709c4.png)

![image](https://user-images.githubusercontent.com/69638895/111910099-06d7f880-8a86-11eb-98f4-035f0fd31f95.png)

![image](https://user-images.githubusercontent.com/69638895/111910123-19eac880-8a86-11eb-9a68-3d70290fe309.png)


Link: https://getbootstrap.com/docs/4.5/components/card/Link: https://getbootstrap.com/docs/4.5/examples/grid/

![image](https://user-images.githubusercontent.com/69638895/111910156-3be44b00-8a86-11eb-9354-c1719987607d.png)


![image](https://user-images.githubusercontent.com/69638895/111910177-4f8fb180-8a86-11eb-885c-dd83048235d0.png)



Link : https://getbootstrap.com/docs/4.5/layout/grid/


![image](https://user-images.githubusercontent.com/69638895/111910207-66360880-8a86-11eb-8e6b-c999c09c92f5.png)


![image](https://user-images.githubusercontent.com/69638895/111910218-76e67e80-8a86-11eb-880f-b114acd28e46.png)


-Addimage-Usegrid
Link:https://getbootstrap.com/docs/4.5/layout/grid/

![image](https://user-images.githubusercontent.com/69638895/111910253-a301ff80-8a86-11eb-8a4a-16407e8b782c.png)


